/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AtivPoo;

/**
 *
 * @author R I C H
 */
public class Principal {
    public static void main(String[] args) {
        Tesr t = new Tesr();
        Mercado m = new Mercado();
        
        m.setVisible(true);
        
        
      
        Exibir ex = new Exibir();
        
        
        ex.add(t);
        
        
        
    }
}
