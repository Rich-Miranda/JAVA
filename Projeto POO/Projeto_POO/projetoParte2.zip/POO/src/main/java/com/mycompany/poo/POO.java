/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.poo;

/**
 *
 * @author R I C H
 */
public class POO {

    public static void main(String[] args) {
        Metodo est = new Metodo();
        
        System.out.println("Area  : "+ est.area(10));
        System.out.println("Circulo : " + est.perimeto(5));
    }
}
