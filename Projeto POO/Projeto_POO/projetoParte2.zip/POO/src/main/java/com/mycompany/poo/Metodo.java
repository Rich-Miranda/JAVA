/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.poo;

/**
 *
 * @author R I C H
 */
public class Metodo {
    private double circulo;

    public double getCirculo() {
        return circulo;
    }

    public void setCirculo(double circulo) {
        this.circulo = circulo;
    }
    
    public double area(double a){
        return   Math.PI *Math.pow(a,2); 
    }
    
    public double perimeto(double a){
        return 2 * Math.PI * area(a);
    }
}
